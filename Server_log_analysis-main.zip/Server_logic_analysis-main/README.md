# Server_logic_analysis
This is an application which based on the issue ticket details fetches the relevant logs and gives the summary of log analysis and action points.
